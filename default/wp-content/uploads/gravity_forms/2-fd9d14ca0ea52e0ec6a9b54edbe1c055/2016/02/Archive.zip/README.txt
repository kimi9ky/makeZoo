
 Alisha Grama
 Project 4
 Wednesday/Friday lab 12:30-1:45
 TAs are Alex Mai and Aries Liang
 I affirm that I have not given or received any unauthorized help
 on this assignment, and that this work is my own.

EDITS: 
I made the screen un-resizable so that the user couldn’t make the game really easy just by resizing it. But the code works perfectly well if you just delete that line (meaning that it works with resizing). I made the velocity go up a little as it bounces off the platform so the game becomes more interesting. That’s about it. It was fun!

Thanks!
