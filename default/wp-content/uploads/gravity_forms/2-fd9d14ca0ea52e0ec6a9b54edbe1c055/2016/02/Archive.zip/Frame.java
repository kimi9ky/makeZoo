import java.awt.Color;

import javax.swing.JFrame;

public class Frame extends JFrame
{
	public Frame()
	{
		setSize(700, 500);
		setTitle("Lob Pong!");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setResizable(false); //so that the difficulty settings can't be changed by resizing the frame
		
		Panel panel = new Panel();
		add(panel);
	}//end of constructor
	
	public static void main(String[] args)
	{
		Frame frame = new Frame();
		frame.setVisible(true);
	}//end of main method

}//end of Frame class
