import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Panel extends JPanel implements MouseMotionListener, MouseListener
{
	protected Timer timer;
	final double G = 9.8;
	double vox = 6;
	double voy = 6;
	public double vx, vy;
	public int x = 7;
	public int y = 60;
	public double theta = Math.toRadians(90);
	public double t = 0;
	private int currentX;
	
	public JLabel timeLabel;
	public JLabel scoreLabel;
	public JLabel livesLabel;
	
	public int score = 0;
	public int timeLeft;
	public int lives = 3;
	
	public Panel()
	{
		addMouseMotionListener(this);
		addMouseListener(this);
		setBackground(Color.CYAN);
		
		timer = new Timer(90, new TimerCallback()); 
		timer.start();
		
		timeLabel = new JLabel();
		scoreLabel = new JLabel();
		livesLabel = new JLabel();
		
		add(timeLabel);
		add(scoreLabel);
		add(livesLabel);
		
	}//end of constructor

	@Override
	public void mouseClicked(MouseEvent e) 
	{
	
	}//end mouseClicked method

	@Override
	public void mousePressed(MouseEvent e) 
	{
		
	}//end mousePressed method

	@Override
	public void mouseReleased(MouseEvent e) 
	{
		
	}//end mouseReleased method

	@Override
	public void mouseEntered(MouseEvent e) 
	{
		
	}//end mouseEntered method

	@Override
	public void mouseExited(MouseEvent e) 
	{
		
	}//end mouseExited method

	@Override
	public void mouseDragged(MouseEvent e)
	{
		
	}//end mouseDragged method

	@Override
	public void mouseMoved(MouseEvent e) 
	{
		currentX = e.getX();
	}//end of mouseMoved method
	
	@Override
	public void paintComponent(Graphics g)
	{
		g.setColor(Color.BLACK);
		g.fillRect(currentX, 430, 90, 10);
		
		g.setColor(Color.MAGENTA);
		g.fillOval(x, y, 11, 11);
		
		repaint();
		
	}//end of paintComponent method
	
	
	protected class TimerCallback implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			t+= .1;
			
			if (x < 0 || x > 700)
				vox = -vx;
			if (y > 420 && (x >= currentX && x <= (currentX + 90)))
			{
				voy = -vy*1.2;
				theta = -theta;
				y = 419;
				score++;
			}
			else if (y < 0)
			{
				voy = -vy;
				t = 0;
			}
			
			if (y > 420 && !(x >= currentX && x <= (currentX + 90)))
				lives--;
			
			vx = vox*Math.cos(0);
			vy = -(voy*Math.sin(theta) - G*t);
			
			x+= vx;
			y+= vy;
			
			timeLeft++;
			
			setLabels();
			
			
		}//end of inner actionPerformed method
		
	}//end of TimerCallback class
	
	public void setLabels()
	{
		timeLabel.setText("Time Remainging: " + timeLeft);
		scoreLabel.setText("Score: " + score);
		livesLabel.setText("Lives Left: " + lives);
	}//end of setLabels class

}//end of Panel class
